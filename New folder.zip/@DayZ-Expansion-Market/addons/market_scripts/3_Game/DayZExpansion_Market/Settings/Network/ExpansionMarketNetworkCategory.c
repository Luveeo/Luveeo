/**
 * ExpansionMarketNetworkCategory.c
 *
 * DayZ Expansion Mod
 * www.dayzexpansion.com
 * © 2022 DayZ Expansion Mod Team
 *
 * This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License. 
 * To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/.
 *
*/

class ExpansionMarketNetworkCategory
{
	string DisplayName;
	string Icon;
	int Color;

	int CategoryID;

	bool IsExchange;

	void ExpansionMarketNetworkCategory( ExpansionMarketCategory category )
	{
		DisplayName = category.DisplayName;
		Icon = category.Icon;
		Color = ExpansionColor.HexToARGB(category.Color);
		CategoryID = category.CategoryID;
		IsExchange = category.IsExchange;
	}
};